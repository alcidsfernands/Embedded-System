import serial
from time import sleep
#from smbus import SMBus
import smbus

def spiArduino():	
	with serial.Serial("/dev/ttyACM0", 9600, timeout=1) as arduino:
		sleep(0.1) #wait for serial to open
		while True:
			lectura = "Basura"
			lectura = str(arduino.readline())
			sensores = lectura.split("_")
			print (sensores[1] + sensores[2] + sensores[3] + sensores[4] + sensores[5])
			sleep(1)

#def I2C(chanel):
	# Open i2c bus and read one byte from address n with offset x
	#el acelerometro esta conectado al canal 2, pines 15 y 17
	#i2c = SMBus(chanel)
	#acelerometro = i2c.read_byte_data(0x98, 100)
	#print (str(acelerometro))


bus = smbus.SMBus(2) 
addr=0x4c
while True:
	Register = bus.read_i2c_block_data(0x4c, 0x9,810)
	acc_x = Register[0]*1.0
	acc_y = Register[1]*1.0
	acc_z = Register[2]*1.0
	acc_tilt = Register[3]
	print(str(acc_x))
	print(str(acc_y))
	print(str(acc_z))
	print(str(acc_tilt))
	print(str(Register))	
	sleep(3)
    x = bus.read_byte_data(addr,0x00)
    y = bus.read_byte_data(addr,0x01)
    z = bus.read_byte_data(addr,0x02)
    tr = bus.read_byte_data(addr,0x03)
    print x, y, z, tr





