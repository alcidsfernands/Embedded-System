#import sys
#sys.path.insert(0, './*')
from consulta_BBDD import consulta
import time
import mysql.connector
import datetime
import serial
#from smbus import SMBus
import smbus
import os

sensores =[0,0,0,0,0,0,0]
acelerometro=0

latitud=[]
longitud=[]


def spiArduino():
    with serial.Serial("/dev/ttyACM",115200, timeout=0) as arduino:
        lectura = str(arduino.readline())
        sensores = lectura.split("_")
        print(str(sensores))
        print('lectura' + lectura)
        time.sleep(1)



#def I2C(chanel):
# Open i2c bus and read one byte from address n with offset x
#el acelerometro esta conectado al canal 2, pines 15 y 17
#i2c = SMBus(chanel)
#acelerometro = i2c.read_byte_data(0x98, 100)
#print (str(acelerometro))

   #ttyACM0


def acel():
    Register = bus.read_i2c_block_data(0x4c, 0x00,4)
    acc_x = Register[0]*1.0
    acc_y = Register[1]*1.0
    acc_z = Register[2]*1.0
    acc_tilt = Register[3]
    print(str(acc_tilt))


f = open("/home/xilinx/coords.txt", "r")
lineas = f.readlines()
f.close()

while True:
    #inicializar I2C en la Ultra
    bus = smbus.SMBus(2) 
    bus.write_byte_data(0x4c, 0x07, 0x00) # Setup the Mode
    bus.write_byte_data(0x4c, 0x06, 0x10) # Calibrate
    bus.write_byte_data(0x4c, 0x08, 0x00) # Calibrate
    bus.write_byte_data(0x4c, 0x07, 0x01) # Calibrate
    arduino=serial.Serial("/dev/ttyACM0",115200, timeout=1)
    
    
    while True:
        arduino.flush()
        lectura = str(arduino.readline())
        receber = lectura.split("_")
        if len(receber)>5:
            sensores=receber
        
        #sensor0=sensores[0].split("'")



        #spiArduino()
        acel()

        tempDI = sensores[6]
        tempDD = sensores[6]
        tempTI = sensores[6]
        tempTD = sensores[6]
        presion=2.5
        rpm = 5000
        giro = sensores[2]
        TEMP = sensores[0]
        TENSION = sensores[6]
        AERO = sensores[4]
        NIVEL = sensores[3]
        DIST = sensores[5]
    
        print('temperatura' + str(tempDI))
        print('giro' + str(giro))
        print('dist' + str(NIVEL))

        consulta.insert_neumatico(presion, tempDI, rpm, giro, "DELANTE_IZQ")
        consulta.insert_neumatico(presion, tempDD, rpm, giro, "DELANTE_DER")
        consulta.insert_neumatico(presion, tempTI, rpm, giro, "ATRAS_IZQ")
        consulta.insert_neumatico(presion, tempTD, rpm, giro, "ATRAS_DER")
        consulta.insert_chasis(TENSION, AERO)
        consulta.insert_UP(NIVEL, TEMP, TENSION)

        for linea in lineas:
            coords = linea.split(',')
            latitud.append(coords[0])
            lon = coords[1].rstrip()
            longitud.append(lon)

        for i in range(len(latitud)):
            punto = "".join(("POINT(",latitud[i]," ", longitud[i],")"))
            consulta.insert_POS(punto, DIST, 1)

    	#print("se ha insertado neumaticos")	